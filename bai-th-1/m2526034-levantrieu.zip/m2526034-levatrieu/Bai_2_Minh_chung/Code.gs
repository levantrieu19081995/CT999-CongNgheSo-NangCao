
function taoBaiKhaoSatTH2() {
  // 1. T?o Google Form
  const form = FormApp.create(
    "KH?O S�T HI?U QU? QU?N L� C�NG VI?C NH�M PH�T TRI?N PH?N M?M"
  );

  form.setDescription(
    "B�I TH?C H�NH 2 - C�NG D�N S? N�NG CAO\n\n" +
    "M?c ti�u: Kh?o s�t th?c tr?ng ph�n c�ng, theo d�i ti?n d? " +
    "v� ph?i h?p trong c�c nh�m ph�t tri?n ph?n m?m.\n\n" +
    "�?i tu?ng: L?p tr�nh vi�n, sinh vi�n v� h?c vi�n " +
    "d� t?ng tham gia d? �n ph�t tri?n ph?n m?m.\n\n" +
    "D? li?u ch? ph?c v? m?c d�ch h?c t?p v� nghi�n c?u. " +
    "Kh�ng y�u c?u cung c?p th�ng tin c� nh�n."
  );

  form.setCollectEmail(false);
  form.setLimitOneResponsePerUser(false);
  form.setConfirmationMessage(
    "C?m on Anh/Ch? d� tham gia kh?o s�t!"
  );

  // H�m th�m c�u h?i tr?c nghi?m
  function tracNghiem(title, options) {
    form.addMultipleChoiceItem()
      .setTitle(title)
      .setChoiceValues(options)
      .setRequired(true);
  }

  // H�m th�m c�u h?i ch?n nhi?u d�p �n
  function nhieuLuaChon(title, options) {
    form.addCheckboxItem()
      .setTitle(title)
      .setChoiceValues(options)
      .setRequired(true);
  }

  // H�m th�m c�u h?i thang do 1-5
  function thangDo(title, low, high) {
    form.addScaleItem()
      .setTitle(title)
      .setBounds(1, 5)
      .setLabels(low, high)
      .setRequired(true);
  }

  // C�u 1
  tracNghiem(
    "1. Vai tr� c?a Anh/Ch? trong nh�m ph�t tri?n ph?n m?m?",
    [
      "L?p tr�nh vi�n",
      "Ki?m th? ph?n m?m (Tester/QA)",
      "Ph�n t�ch nghi?p v? (BA)",
      "Tru?ng nh�m / Qu?n l� d? �n",
      "Sinh vi�n / H?c vi�n th?c hi?n d? �n",
      "Vai tr� kh�c"
    ]
  );

  // C�u 2
  tracNghiem(
    "2. Kinh nghi?m tham gia l�m vi?c nh�m ph�t tri?n ph?n m?m?",
    [
      "Du?i 1 nam",
      "T? 1 d?n du?i 3 nam",
      "T? 3 d?n du?i 5 nam",
      "T? 5 nam tr? l�n"
    ]
  );

  // C�u 3
  nhieuLuaChon(
    "3. Nh�m c?a Anh/Ch? s? d?ng c�ng c? n�o d? qu?n l� c�ng vi?c?",
    [
      "Trello",
      "Jira",
      "GitHub Projects / GitLab",
      "Google Sheets / Excel",
      "Notion",
      "Chua s? d?ng c�ng c? chuy�n bi?t",
      "C�ng c? kh�c"
    ]
  );

  // C�u 4
  tracNghiem(
    "4. Nh�m thu?ng c?p nh?t ti?n d? c�ng vi?c v?i t?n su?t n�o?",
    [
      "H?ng ng�y",
      "2-3 l?n m?i tu?n",
      "M?i tu?n m?t l?n",
      "�t hon m?t l?n m?i tu?n",
      "Kh�ng c� l?ch c?p nh?t c? d?nh"
    ]
  );

  // C�u 5
  thangDo(
    "5. M?c d? r� r�ng khi ph�n c�ng nhi?m v? trong nh�m?",
    "1 - R?t kh�ng r� r�ng",
    "5 - R?t r� r�ng"
  );

  // C�u 6
  thangDo(
    "6. M?c d? d? d�ng khi theo d�i ti?n d? c�ng vi?c?",
    "1 - R?t kh�",
    "5 - R?t d?"
  );

  // C�u 7
  tracNghiem(
    "7. Nh�m c� thu?ng xuy�n x?y ra t�nh tr?ng tr? h?n c�ng vi?c kh�ng?",
    [
      "R?t thu?ng xuy�n",
      "Thu?ng xuy�n",
      "Th?nh tho?ng",
      "Hi?m khi",
      "Kh�ng bao gi?"
    ]
  );

  // C�u 8
  nhieuLuaChon(
    "8. Nh?ng kh� khan n�o thu?ng g?p khi ph?i h?p c�ng vi?c?",
    [
      "Ph�n c�ng nhi?m v? chua r� r�ng",
      "Kh� theo d�i ti?n d?",
      "Trao d?i th�ng tin chua k?p th?i",
      "Thay d?i y�u c?u li�n t?c",
      "Thi?u t�i li?u ho?c th�ng tin",
      "Kh?i lu?ng c�ng vi?c chua h?p l�",
      "Kh�ng g?p kh� khan d�ng k?"
    ]
  );

  // C�u 9
  thangDo(
    "9. M?c d? hi?u qu? c?a vi?c giao ti?p trong nh�m?",
    "1 - R?t k�m",
    "5 - R?t hi?u qu?"
  );

  // C�u 10
  thangDo(
    "10. M?c d? h�i l�ng v?i phuong ph�p qu?n l� c�ng vi?c hi?n t?i?",
    "1 - R?t kh�ng h�i l�ng",
    "5 - R?t h�i l�ng"
  );

  // C�u 11
  tracNghiem(
    "11. Anh/Ch? c� s?n s�ng s? d?ng Trello d? qu?n l� c�ng vi?c nh�m?",
    [
      "R?t s?n s�ng",
      "S?n s�ng",
      "C?n t�m hi?u th�m",
      "Kh�ng s?n s�ng",
      "�ang s? d?ng Trello"
    ]
  );

  // C�u 12
  form.addParagraphTextItem()
    .setTitle(
      "12. Anh/Ch? d? xu?t gi?i ph�p g� d? n�ng cao " +
      "hi?u qu? qu?n l� c�ng vi?c nh�m ph�t tri?n ph?n m?m?"
    )
    .setRequired(false);

  // 2. T?o Google Sheets nh?n ph?n h?i
  const sheet = SpreadsheetApp.create(
    "TH2 - Du lieu khao sat quan ly nhom phat trien phan mem"
  );

  form.setDestination(
    FormApp.DestinationType.SPREADSHEET,
    sheet.getId()
  );

  // 3. Ghi li�n k?t d? ngu?i d�ng m?
  Logger.log("=== T?O KH?O S�T TH�NH C�NG ===");
  Logger.log("CH?NH S?A FORM: " + form.getEditUrl());
  Logger.log("G?I KH?O S�T: " + form.getPublishedUrl());
  Logger.log("GOOGLE SHEETS: " + sheet.getUrl());
  Logger.log("S? C�U H?I: " + form.getItems().length);
}
